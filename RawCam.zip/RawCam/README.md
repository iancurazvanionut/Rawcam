# RawCam

Aplicație Android care folosește **Camera2 API** direct, ca să ocolească:
1. curba de zoom fixă a aplicației Samsung Camera (care ascunde lentila
   ultra-wide sub un buton "1x/3x" în loc să-ți dea acces liber la 0.5x/0.6x),
2. lanțul de postprocesare (sharpening, noise reduction, AI) aplicat pe
   JPEG-urile de pe camera de 200MP.

## Ce face concret
- **Enumeră toate lentilele fizice din spate** (Camera2 le vede separat,
  chiar dacă Samsung le ascunde) și le etichetează după zoom relativ
  (ex: 0.5x, 1x, 3x), calculat din lungimea focală echivalentă 35mm.
- Poți comuta între ele apăsând pe buton — e switch de lentilă fizică,
  nu crop digital.
- **Captură RAW_SENSOR (.dng)** — date brute de pe senzor, salvate cu
  `DngCreator`, fără nicio procesare de imagine.
- Când o lentilă nu suportă RAW (frecvent la ultra-wide/tele), cade automat
  pe JPEG cu `EDGE_MODE_OFF` și `NOISE_REDUCTION_MODE_OFF` — tot ce se poate
  dezactiva prin API public.
- Poți opri RAW din butonul "RAW: ON/OFF" dacă vrei doar JPEG-ul curat
  (fișiere mai mici, fără editor RAW necesar).
- Salvează în `Pictures/RawCam` prin MediaStore.

## Cum compilezi
1. Instalează [Android Studio](https://developer.android.com/studio).
2. Deschide folderul acestui proiect ("Open an existing project").
3. Lasă Gradle sync să descarce dependențele (are nevoie de net la
   `google()` / `mavenCentral()`).
4. Conectează telefonul (Developer Options → USB debugging) și apasă Run,
   sau `Build > Build Bundle(s)/APK(s) > Build APK(s)`.
5. La prima pornire, acordă permisiunea de cameră.

## Limitări reale — nu ipotetice
- **RAW nu e garantat pe toate lentilele.** Multe telefoane (Samsung
  incluse, în funcție de model) expun `REQUEST_AVAILABLE_CAPABILITIES_RAW`
  doar pe camera principală. Ultra-wide-ul de multe ori nu are RAW deloc la
  nivel de driver — aici aplicația nu poate face nimic în plus, e limită de
  firmware/HAL, nu de aplicație.
- **Nivelul hardware Camera2** (`INFO_SUPPORTED_HARDWARE_LEVEL`) diferă pe
  modele/regiuni Samsung — pe unele e `FULL`/`LEVEL_3` (acces bun), pe
  altele `LIMITED` (mai restrictiv). Statusul afișat în aplicație îți arată
  ce ai obținut efectiv pe telefonul tău.
- Etichetele de zoom (0.5x, 1x...) sunt **calculate**, nu citite dintr-un
  API oficial de "zoom factor" — Android nu are un asemenea API standard;
  se bazează pe geometria senzor/lentilă, deci pot diferi puțin de ce arată
  Samsung Camera.
- Fișierele `.dng` sunt mari (10-25 MB) și ai nevoie de un editor RAW
  (Lightroom, Snapseed, Adobe Camera Raw pe desktop) ca să le procesezi —
  ele sunt intenționat "plate"/needitate.
- Nu am putut compila un `.apk` în acest mediu (fără acces la Google's
  Maven), deci codul e testat structural, nu rulat pe hardware real —
  probabil vei ajusta lucruri mărunte (ex: dimensiuni preview pe telefonul
  tău specific) la primul build.

## Idei de extins ulterior
- Slider de expunere/ISO manual (`CONTROL_AE_MODE_OFF` +
  `SENSOR_SENSITIVITY` / `SENSOR_EXPOSURE_TIME`).
- White balance manual (`CONTROL_AWB_MODE_OFF` + `COLOR_CORRECTION_GAINS`).
- Histogramă live.
- Burst RAW.
