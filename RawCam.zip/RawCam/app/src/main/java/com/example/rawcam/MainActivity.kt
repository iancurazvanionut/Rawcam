package com.example.rawcam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.Image
import android.media.ImageReader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * RawCam — acces direct la fiecare lentilă fizică din spate (fără curba de
 * zoom / cropping a aplicației producătorului) și captură RAW_SENSOR (DNG),
 * ocolind lanțul de postprocesare (sharpening / noise-reduction / AI) pe
 * care multe telefoane (inclusiv Samsung) îl aplică implicit pe JPEG.
 *
 * IMPORTANT / limitări reale, nu ipotetice:
 *  - Nu toate lentilele suportă RAW_SENSOR. De multe ori DOAR camera
 *    principală (wide) o suportă; ultra-wide / tele cad automat pe JPEG
 *    "curat" (EDGE_MODE_OFF, NOISE_REDUCTION_MODE_OFF).
 *  - Pe unele Samsung, HAL-ul Camera2 rulează la nivel LIMITED/LEGACY în
 *    funcție de model/regiune/one-ui, ceea ce restricționează și mai mult
 *    ce se poate cere manual. Aplicația verifică asta și afișează statusul.
 *  - Etichetele "0.5x / 1x / 3x" sunt calculate din lungimea focală
 *    echivalentă 35mm a fiecărei camere fizice, relativ la lentila cea mai
 *    apropiată de ~24-26mm (considerată "1x"/wide principal). E o
 *    aproximare rezonabilă, nu un număr garantat de OEM.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var viewFinder: TextureView
    private lateinit var lensButtonsContainer: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var captureButton: Button
    private lateinit var rawToggleButton: Button

    private lateinit var cameraManager: CameraManager
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null

    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private data class LensInfo(
        val id: String,
        val focal35mm: Float,
        val supportsRaw: Boolean,
        val previewSize: Size,
        val rawSize: Size?,
        val jpegSize: Size?
    )

    private var lenses: List<LensInfo> = emptyList()
    private var currentLens: LensInfo? = null
    private var rawEnabled = true
    private var currentCaptureResult: CaptureResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewFinder = findViewById(R.id.viewFinder)
        lensButtonsContainer = findViewById(R.id.lensButtonsContainer)
        statusText = findViewById(R.id.statusText)
        captureButton = findViewById(R.id.captureButton)
        rawToggleButton = findViewById(R.id.rawToggleButton)

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager

        captureButton.setOnClickListener { takePhoto() }
        rawToggleButton.setOnClickListener {
            rawEnabled = !rawEnabled
            rawToggleButton.text = if (rawEnabled) "RAW: ON" else "RAW: OFF (JPEG curat)"
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 100)
        } else {
            enumerateLenses()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enumerateLenses()
            } else {
                Toast.makeText(this, R.string.permission_denied, Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    // ---------- Enumerare lentile fizice spate ----------

    private fun enumerateLenses() {
        val found = mutableListOf<LensInfo>()
        for (id in cameraManager.cameraIdList) {
            try {
                val chars = cameraManager.getCameraCharacteristics(id)
                if (chars.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue

                val focalLengths = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                val sensorSize = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                if (focalLengths == null || focalLengths.isEmpty() || sensorSize == null) continue

                // echivalent 35mm ≈ focal * (36 / lățime_senzor_fizic_mm)
                val focal35 = focalLengths[0] * (36f / sensorSize.width)

                val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                val supportsRaw = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)

                val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val previewSize = pickPreviewSize(map)
                val rawSize = if (supportsRaw) map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { it.width * it.height } else null
                val jpegSize = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width * it.height }

                found.add(LensInfo(id, focal35, supportsRaw, previewSize, rawSize, jpegSize))
            } catch (e: Exception) {
                Log.w("RawCam", "Nu pot citi camera $id: ${e.message}")
            }
        }

        if (found.isEmpty()) {
            statusText.text = "Nicio cameră spate găsită prin Camera2."
            return
        }

        lenses = found.sortedBy { it.focal35mm }
        // referința "1x" = lentila cea mai apropiată de o focală echivalentă de 24-26mm
        val reference = lenses.minByOrNull { kotlin.math.abs(it.focal35mm - 25f) } ?: lenses.first()

        buildLensButtons(reference)
        currentLens = reference
        startBackgroundThread()

        if (viewFinder.isAvailable) {
            openCamera(reference)
        } else {
            viewFinder.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                    openCamera(reference)
                }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }
    }

    private fun pickPreviewSize(map: StreamConfigurationMap?): Size {
        val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
        return sizes?.filter { it.width <= 1920 }?.maxByOrNull { it.width * it.height }
            ?: Size(1280, 720)
    }

    private fun buildLensButtons(reference: LensInfo) {
        lensButtonsContainer.removeAllViews()
        for (lens in lenses) {
            val zoomFactor = reference.focal35mm / lens.focal35mm
            val label = String.format(Locale.US, "%.1fx%s", zoomFactor, if (lens.supportsRaw) " RAW" else "")
            val btn = Button(this)
            btn.text = label
            btn.setOnClickListener { switchLens(lens) }
            lensButtonsContainer.addView(btn)
        }
    }

    private fun switchLens(lens: LensInfo) {
        if (lens.id == currentLens?.id) return
        closeCamera()
        currentLens = lens
        openCamera(lens)
    }

    // ---------- Deschidere cameră + sesiune preview ----------

    private fun openCamera(lens: LensInfo) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            cameraManager.openCamera(lens.id, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    cameraDevice = device
                    createPreviewSession(lens)
                }
                override fun onDisconnected(device: CameraDevice) {
                    device.close(); cameraDevice = null
                }
                override fun onError(device: CameraDevice, error: Int) {
                    device.close(); cameraDevice = null
                    runOnUiThread { statusText.text = "Eroare cameră ${lens.id}: cod $error" }
                }
            }, backgroundHandler)
        } catch (e: SecurityException) {
            Log.e("RawCam", "Fără permisiune cameră", e)
        } catch (e: CameraAccessException) {
            statusText.text = "Nu pot accesa camera ${lens.id}: ${e.reason}"
        }
    }

    private fun createPreviewSession(lens: LensInfo) {
        val texture = viewFinder.surfaceTexture ?: return
        texture.setDefaultBufferSize(lens.previewSize.width, lens.previewSize.height)
        val previewSurface = Surface(texture)

        // reader pentru captura efectivă (RAW dacă disponibil & activat, altfel JPEG "curat")
        val useRaw = rawEnabled && lens.supportsRaw && lens.rawSize != null
        val captureSize = if (useRaw) lens.rawSize!! else (lens.jpegSize ?: lens.previewSize)
        val captureFormat = if (useRaw) ImageFormat.RAW_SENSOR else ImageFormat.JPEG

        imageReader?.close()
        imageReader = ImageReader.newInstance(captureSize.width, captureSize.height, captureFormat, 2).apply {
            setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                saveImage(image, useRaw, lens)
            }, backgroundHandler)
        }

        val targets = listOf(previewSurface, imageReader!!.surface)
        cameraDevice?.createCaptureSession(targets, object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                val requestBuilder = cameraDevice!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                requestBuilder.addTarget(previewSurface)
                requestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                requestBuilder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
                requestBuilder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF)
                session.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler)

                runOnUiThread {
                    val mode = if (useRaw) "RAW (DNG, ${captureSize.width}x${captureSize.height})"
                               else "JPEG curat (fără sharpening/NR), ${captureSize.width}x${captureSize.height}"
                    statusText.text = "Lentilă ${lens.id} · ${String.format(Locale.US, "%.1fmm eq", lens.focal35mm)} · $mode"
                }
            }
            override fun onConfigureFailed(session: CameraCaptureSession) {
                runOnUiThread { statusText.text = "Configurare sesiune eșuată pentru lentila ${lens.id}" }
            }
        }, backgroundHandler)
    }

    // ---------- Captură ----------

    private fun takePhoto() {
        val session = captureSession ?: return
        val device = cameraDevice ?: return
        val reader = imageReader ?: return
        val lens = currentLens ?: return

        try {
            val builder = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            builder.addTarget(reader.surface)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            builder.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF)
            builder.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF)
            builder.set(CaptureRequest.JPEG_QUALITY, 100.toByte())

            session.capture(builder.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult
                ) {
                    currentCaptureResult = result
                }
            }, backgroundHandler)

            runOnUiThread { Toast.makeText(this, "Captură...", Toast.LENGTH_SHORT).show() }
        } catch (e: CameraAccessException) {
            Log.e("RawCam", "Eroare la captură", e)
        }
    }

    private fun saveImage(image: Image, isRaw: Boolean, lens: LensInfo) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
        val filename = "RAWCAM_${timestamp}_${lens.id}"

        try {
            if (isRaw) {
                val chars = cameraManager.getCameraCharacteristics(lens.id)
                val result = currentCaptureResult
                if (result == null) {
                    image.close(); return
                }
                val dngCreator = DngCreator(chars, result)
                val outputStream: OutputStream? = openOutputStream("$filename.dng", "image/x-adobe-dng")
                outputStream?.use { dngCreator.writeImage(it, image) }
                dngCreator.close()
            } else {
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                val outputStream: OutputStream? = openOutputStream("$filename.jpg", "image/jpeg")
                outputStream?.use { it.write(bytes) }
            }
            runOnUiThread { Toast.makeText(this, "Salvat: $filename", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            Log.e("RawCam", "Eroare la salvare", e)
            runOnUiThread { Toast.makeText(this, "Eroare salvare: ${e.message}", Toast.LENGTH_LONG).show() }
        } finally {
            image.close()
        }
    }

    /** Salvează prin MediaStore (Android 10+) în Pictures/RawCam, sau direct pe stocare pe versiuni vechi. */
    private fun openOutputStream(displayName: String, mimeType: String): OutputStream? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/RawCam")
            }
            val uri: Uri? = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let { contentResolver.openOutputStream(it) }
        } else {
            val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "RawCam")
            if (!dir.exists()) dir.mkdirs()
            FileOutputStream(java.io.File(dir, displayName))
        }
    }

    // ---------- Ciclu de viață ----------

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("RawCamBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
    }

    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            Log.e("RawCam", "Eroare oprire thread", e)
        }
    }

    private fun closeCamera() {
        captureSession?.close(); captureSession = null
        cameraDevice?.close(); cameraDevice = null
        imageReader?.close(); imageReader = null
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (backgroundThread == null) startBackgroundThread()
        currentLens?.let { lens ->
            if (viewFinder.isAvailable) openCamera(lens)
        }
    }
}
